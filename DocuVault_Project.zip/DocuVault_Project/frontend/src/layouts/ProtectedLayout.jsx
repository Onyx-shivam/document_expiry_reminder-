import React from "react";   // ✅ THIS WAS MISSING
import Sidebar from "../components/Sidebar";
import { Outlet } from "react-router-dom";

export default function ProtectedLayout() {
  return (
    <div style={{ display: "flex", minHeight: "100vh" }}>
      <Sidebar />
      <div style={{ flex: 1, padding: "30px", background: "#f5f7fb" }}>
        <Outlet />
      </div>
    </div>
  );
}
