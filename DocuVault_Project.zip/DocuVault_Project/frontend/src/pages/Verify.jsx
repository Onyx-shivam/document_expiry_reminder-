import React from "react";
import { useState } from "react";
import api from "../services/api";
import { useNavigate } from "react-router-dom";

export default function Verify() {
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const navigate = useNavigate();

  const verifyOtp = async () => {
    try {
      await api.post("/auth/verify", { email, otp });

      alert("OTP verified successfully. Please login.");

      // ✅ redirect to LOGIN page
      navigate("/");
    } catch (err) {
      alert("Invalid OTP");
    }
  };

  return (
    <div className="auth-container">
      <h3>Email Verification</h3>

      <input
        className="form-control mb-2"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />

      <input
        className="form-control mb-3"
        placeholder="OTP"
        value={otp}
        onChange={(e) => setOtp(e.target.value)}
      />

      <button className="btn btn-success w-100" onClick={verifyOtp}>
        Verify OTP
      </button>
    </div>
  );
}
