import React, { useState } from "react";
import api from "../services/api";
import { useNavigate } from "react-router-dom";

export default function AddDocument() {
  const navigate = useNavigate();

  const [title, setTitle] = useState("");
  const [issueDate, setIssueDate] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [reminderDays, setReminderDays] = useState("");
  const [file, setFile] = useState(null);

  const saveDocument = async () => {
  if (!title || !issueDate || !expiryDate) {
    alert("Please fill all required fields");
    return;
  }

  try {
    const formData = new FormData();
    formData.append("title", title);
    formData.append("issue_date", issueDate);
    formData.append("expiry_date", expiryDate);
    formData.append("reminder_days", reminderDays);
    if (file) formData.append("document", file); // ✅ FIX

    await api.post("/documents", formData);

    alert("Document added successfully");
    navigate("/documents");
  } catch (err) {
    console.error(err);
    alert("Something went wrong. Please try again.");
  }
};

  return (
    <div style={{ display: "flex", justifyContent: "center" }}>
      <div style={card}>
        <h2>➕ Add Document</h2>

        <input
          className="form-control mb-3"
          placeholder="Document Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />

        <input
          type="date"
          className="form-control mb-3"
          value={issueDate}
          onChange={(e) => setIssueDate(e.target.value)}
        />

        <input
          type="date"
          className="form-control mb-3"
          value={expiryDate}
          onChange={(e) => setExpiryDate(e.target.value)}
        />

        <input
          className="form-control mb-3"
          placeholder="Reminder Days (e.g. 3)"
          value={reminderDays}
          onChange={(e) => setReminderDays(e.target.value)}
        />

        <input
          type="file"
          className="form-control mb-3"
          onChange={(e) => setFile(e.target.files[0])}
        />

        <button className="btn btn-primary w-100" onClick={saveDocument}>
          Save Document
        </button>
      </div>
    </div>
  );
}

const card = {
  background: "#fff",
  padding: "30px",
  borderRadius: "14px",
  width: "420px",
  boxShadow: "0 12px 25px rgba(0,0,0,0.12)",
};
