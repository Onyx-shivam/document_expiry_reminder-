import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../services/api";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const login = async () => {
    if (!email || !password) {
      alert("Please fill all fields");
      return;
    }

    try {
      const res = await api.post("/auth/login", { email, password });
      localStorage.setItem("token", res.data.token);
      navigate("/dashboard");
    } catch (err) {
      alert(err.response?.data?.msg || "Login failed");
    }
  };

  return (
    <div style={container}>
      <div style={card}>
        <div style={{ textAlign: "center" }}>
          <div style={icon}>📄</div>
          <h2>Document Reminder</h2>
          <p style={{ color: "#555" }}>Login to your account</p>
        </div>

        <label>Email</label>
        <input
          style={input}
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <label>Password</label>
        <input
          style={input}
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button style={button} onClick={login}>
          ➡️ Login
        </button>

        <p style={{ textAlign: "center", marginTop: "15px" }}>
          Don't have an account?{" "}
          <Link to="/register" style={link}>
            Register here
          </Link>
        </p>
      </div>
    </div>
  );
}

/* ===== STYLES ===== */
const container = {
  minHeight: "100vh",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  background: "#f3f6fb",
};

const card = {
  width: "420px",
  padding: "30px",
  background: "#fff",
  borderRadius: "14px",
  boxShadow: "0 10px 25px rgba(0,0,0,0.15)",
};

const icon = {
  fontSize: "40px",
  marginBottom: "10px",
};

const input = {
  width: "100%",
  padding: "10px",
  marginBottom: "15px",
  borderRadius: "6px",
  border: "1px solid #ccc",
};

const button = {
  width: "100%",
  padding: "12px",
  background: "#2563eb",
  color: "#fff",
  border: "none",
  borderRadius: "8px",
  fontSize: "16px",
  cursor: "pointer",
};

const link = {
  color: "#2563eb",
  textDecoration: "none",
};
