import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../services/api";

export default function Register() {
  const navigate = useNavigate();

  const [step, setStep] = useState(1); // 1 = register, 2 = otp
  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
    otp: "",
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  /* ================= REGISTER ================= */
  const register = async (e) => {
    e.preventDefault();

    if (
      !form.name ||
      !form.email ||
      !form.password ||
      !form.confirmPassword
    ) {
      return alert("All fields are required");
    }

    if (form.password !== form.confirmPassword) {
      return alert("Passwords do not match");
    }

    setLoading(true);
    try {
      await api.post("/auth/register", {
        name: form.name,
        email: form.email,
        password: form.password,
      });

      alert("OTP sent to your email");
      setStep(2); // show OTP section
    } catch (err) {
      alert(err.response?.data?.msg || "Registration failed");
    }
    setLoading(false);
  };

  /* ================= VERIFY OTP ================= */
  const verifyOtp = async () => {
    if (!form.otp) return alert("Enter OTP");

    setLoading(true);
    try {
      await api.post("/auth/verify-otp", {
        email: form.email,
        otp: form.otp,
      });

      alert("Registration verified. Please login.");
      navigate("/login");
    } catch (err) {
      alert(err.response?.data?.msg || "Invalid OTP");
    }
    setLoading(false);
  };

  return (
    <div style={container}>
      <div style={card}>
        <h2 style={{ textAlign: "center" }}>Create Account</h2>
        <p style={{ textAlign: "center", color: "#666" }}>
          Register for document tracking
        </p>

        {/* ===== STEP 1: REGISTER ===== */}
        {step === 1 && (
          <form onSubmit={register}>
            <input
              name="name"
              placeholder="Full Name"
              style={input}
              onChange={handleChange}
            />
            <input
              name="email"
              type="email"
              placeholder="Email Address"
              style={input}
              onChange={handleChange}
            />
            <input
              name="password"
              type="password"
              placeholder="Password"
              style={input}
              onChange={handleChange}
            />
            <input
              name="confirmPassword"
              type="password"
              placeholder="Confirm Password"
              style={input}
              onChange={handleChange}
            />

            <button style={button} disabled={loading}>
              {loading ? "Processing..." : "Register"}
            </button>
          </form>
        )}

        {/* ===== STEP 2: OTP ===== */}
        {step === 2 && (
          <>
            <input
              name="otp"
              placeholder="Enter OTP"
              style={input}
              onChange={handleChange}
            />

            <button style={button} onClick={verifyOtp} disabled={loading}>
              {loading ? "Verifying..." : "Verify OTP"}
            </button>
          </>
        )}

        <p style={{ textAlign: "center", marginTop: 15 }}>
          Already have an account? <Link to="/login">Login here</Link>
        </p>
      </div>
    </div>
  );
}

/* ================= STYLES ================= */

const container = {
  height: "100vh",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  background: "#f4f6f8",
};

const card = {
  width: "430px",
  padding: "30px",
  borderRadius: "14px",
  background: "#fff",
  boxShadow: "0 15px 40px rgba(0,0,0,0.12)",
};

const input = {
  width: "100%",
  padding: "12px",
  marginBottom: "15px",
  borderRadius: "8px",
  border: "1px solid #ccc",
  fontSize: "15px",
};

const button = {
  width: "100%",
  padding: "12px",
  background: "#2563eb",
  color: "#fff",
  border: "none",
  borderRadius: "8px",
  fontSize: "16px",
  cursor: "pointer",
};
