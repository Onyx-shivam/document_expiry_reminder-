// import React from "react";
// import { Link } from "react-router-dom";

// export default function Home() {
//   return (
//     <div style={page}>
//       <div style={card}>
//         <h1 style={title}>📄 DocuVault</h1>

//         <p style={subtitle}>
//           A secure and smart way to manage your important documents
//           and never miss an expiry date again.
//         </p>

//         <div style={features}>
//           <div style={featureCard}>
//             <h3>🔐 Secure Storage</h3>
//             <p>
//               Store all your important documents in one safe place with
//               full authentication.
//             </p>
//           </div>

//           <div style={featureCard}>
//             <h3>⏰ Expiry Reminders</h3>
//             <p>
//               Get timely email reminders before your documents expire.
//             </p>
//           </div>

//           <div style={featureCard}>
//             <h3>📊 Smart Dashboard</h3>
//             <p>
//               View document status, expiry, and reminders in a clean dashboard.
//             </p>
//           </div>
//         </div>

//         <div style={actions}>
//           <Link to="/login">
//             <button style={loginBtn}>Login</button>
//           </Link>

//           <Link to="/register">
//             <button style={registerBtn}>Register</button>
//           </Link>
//         </div>
//       </div>
//     </div>
//   );
// }

// /* ===== STYLES ===== */

// const page = {
//   minHeight: "100vh",
//   background: "linear-gradient(135deg, #6c63ff, #5a54e8)",
//   display: "flex",
//   justifyContent: "center",
//   alignItems: "center",
//   padding: "20px",
// };

// const card = {
//   background: "#ffffff",
//   borderRadius: "16px",
//   padding: "40px",
//   maxWidth: "900px",
//   width: "100%",
//   textAlign: "center",
//   boxShadow: "0 20px 40px rgba(0,0,0,0.15)",
// };

// const title = {
//   fontSize: "42px",
//   marginBottom: "10px",
//   color: "#2c2c54",
// };

// const subtitle = {
//   fontSize: "18px",
//   color: "#555",
//   marginBottom: "40px",
// };

// const features = {
//   display: "grid",
//   gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
//   gap: "20px",
//   marginBottom: "40px",
// };

// const featureCard = {
//   background: "#f5f7fb",
//   padding: "20px",
//   borderRadius: "12px",
// };

// const actions = {
//   display: "flex",
//   justifyContent: "center",
//   gap: "20px",
//   flexWrap: "wrap",
// };

// const loginBtn = {
//   padding: "12px 30px",
//   background: "#6c63ff",
//   color: "#fff",
//   border: "none",
//   borderRadius: "8px",
//   fontSize: "16px",
//   cursor: "pointer",
// };

// const registerBtn = {
//   padding: "12px 30px",
//   background: "#2ecc71",
//   color: "#fff",
//   border: "none",
//   borderRadius: "8px",
//   fontSize: "16px",
//   cursor: "pointer",
// };

import React from "react";
import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div>
      {/* ===== HERO SECTION ===== */}
      <section style={hero}>
        <div style={heroContent}>
          <h1 style={heroTitle}>📄 DocuVault</h1>
          <p style={heroText}>
            Securely store your important documents and get smart reminders
            before they expire.
          </p>

          <div style={heroButtons}>
            <Link to="/login">
              <button style={primaryBtn}>Login</button>
            </Link>
            <Link to="/register">
              <button style={secondaryBtn}>Register</button>
            </Link>
          </div>
        </div>

        <img
          src="https://images.unsplash.com/photo-1600267165477-6d4cc741b379"
          alt="Documents"
          style={heroImage}
        />
      </section>

      {/* ===== ABOUT SECTION ===== */}
      <section style={section}>
        <h2 style={sectionTitle}>About DocuVault</h2>
        <p style={sectionText}>
          DocuVault is a smart document management system designed to help you
          keep track of important documents like ID cards, licenses, certificates,
          and more. Never miss an expiry date again.
        </p>
      </section>

      {/* ===== FEATURES SECTION ===== */}
      <section style={featuresSection}>
        <h2 style={sectionTitle}>Key Features</h2>

        <div style={featuresGrid}>
          <div style={featureCard}>
            <h3>🔐 Secure Authentication</h3>
            <p>JWT-based login system to keep your data safe.</p>
          </div>

          <div style={featureCard}>
            <h3>⏰ Email Reminders</h3>
            <p>Automatic email alerts before your documents expire.</p>
          </div>

          <div style={featureCard}>
            <h3>📊 Smart Dashboard</h3>
            <p>View active, expiring, and expired documents at a glance.</p>
          </div>

          <div style={featureCard}>
            <h3>📁 Easy Document Upload</h3>
            <p>Add and manage documents with issue & expiry dates.</p>
          </div>
        </div>
      </section>

      {/* ===== IMAGE + CONTENT SECTION ===== */}
      <section style={splitSection}>
        <img
          src="https://images.unsplash.com/photo-1554224154-22dec7ec8818"
          alt="Dashboard Preview"
          style={splitImage}
        />

        <div>
          <h2 style={sectionTitle}>Why Choose DocuVault?</h2>
          <p style={sectionText}>
            Managing documents manually is risky and time-consuming.
            DocuVault automates the entire process so you can focus on
            what really matters.
          </p>
          <ul style={list}>
            <li>✔ Never miss expiry dates</li>
            <li>✔ Centralized document storage</li>
            <li>✔ Clean and responsive UI</li>
            <li>✔ Works on desktop & mobile</li>
          </ul>
        </div>
      </section>

      {/* ===== CALL TO ACTION ===== */}
      <section style={cta}>
        <h2>Start Using DocuVault Today</h2>
        <p>Simple. Secure. Smart document management.</p>

        <Link to="/register">
          <button style={primaryBtn}>Get Started</button>
        </Link>
      </section>

      {/* ===== FOOTER ===== */}
      <footer style={footer}>
        <p>© {new Date().getFullYear()} DocuVault</p>
        <p>Document Expiry Reminder System</p>
      </footer>
    </div>
  );
}

/* ===== STYLES ===== */

const hero = {
  minHeight: "100vh",
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  padding: "60px",
  background: "linear-gradient(135deg, #6c63ff, #5a54e8)",
  color: "#fff",
  flexWrap: "wrap",
};

const heroContent = {
  maxWidth: "520px",
};

const heroTitle = {
  fontSize: "48px",
  marginBottom: "20px",
};

const heroText = {
  fontSize: "18px",
  marginBottom: "30px",
};

const heroButtons = {
  display: "flex",
  gap: "16px",
};

const heroImage = {
  width: "420px",
  borderRadius: "16px",
  boxShadow: "0 20px 40px rgba(0,0,0,0.3)",
};

const primaryBtn = {
  padding: "12px 28px",
  background: "#fff",
  color: "#6c63ff",
  border: "none",
  borderRadius: "8px",
  fontSize: "16px",
  cursor: "pointer",
};

const secondaryBtn = {
  padding: "12px 28px",
  background: "transparent",
  color: "#fff",
  border: "2px solid #fff",
  borderRadius: "8px",
  fontSize: "16px",
  cursor: "pointer",
};

const section = {
  padding: "80px 20px",
  textAlign: "center",
  maxWidth: "900px",
  margin: "auto",
};

const sectionTitle = {
  fontSize: "32px",
  marginBottom: "20px",
};

const sectionText = {
  fontSize: "17px",
  color: "#555",
};

const featuresSection = {
  background: "#f5f7fb",
  padding: "80px 20px",
};

const featuresGrid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
  gap: "20px",
  maxWidth: "1000px",
  margin: "40px auto 0",
};

const featureCard = {
  background: "#fff",
  padding: "24px",
  borderRadius: "14px",
  boxShadow: "0 10px 25px rgba(0,0,0,0.08)",
};

const splitSection = {
  display: "grid",
  gridTemplateColumns: "1fr 1fr",
  gap: "40px",
  alignItems: "center",
  padding: "80px 40px",
  maxWidth: "1100px",
  margin: "auto",
};

const splitImage = {
  width: "100%",
  borderRadius: "14px",
};

const list = {
  marginTop: "20px",
  lineHeight: "1.8",
};

const cta = {
  textAlign: "center",
  padding: "80px 20px",
  background: "#6c63ff",
  color: "#fff",
};

const footer = {
  textAlign: "center",
  padding: "30px",
  background: "#222",
  color: "#aaa",
};
