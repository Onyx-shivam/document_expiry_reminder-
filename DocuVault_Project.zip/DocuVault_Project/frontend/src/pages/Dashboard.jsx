import React, { useEffect, useState } from "react";
import api from "../services/api";
import { Link } from "react-router-dom";

export default function Dashboard() {
  const [documents, setDocuments] = useState([]);

  useEffect(() => {
    loadDocuments();
  }, []);

  const loadDocuments = async () => {
    try {
      const res = await api.get("/documents");
      setDocuments(res.data);
    } catch (err) {
      console.error(err);
      alert("Failed to load documents");
    }
  };

  /* ===== DATE FORMAT (12-hour clock) ===== */
  const formatDateTime = (dateStr) => {
    if (!dateStr) return "-";

    const date = new Date(dateStr);
    return date.toLocaleString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });
  };

  /* ===== STATS LOGIC ===== */
  const today = new Date();
  const total = documents.length;

  const expired = documents.filter(
    (d) => new Date(d.expiry_date) < today
  ).length;

  const expiringSoon = documents.filter((d) => {
    const diff =
      (new Date(d.expiry_date) - today) / (1000 * 60 * 60 * 24);
    return diff >= 0 && diff <= 7;
  }).length;

  const active = total - expired - expiringSoon;

  return (
    <div style={page}>
      <h1 style={{ marginBottom: "20px" }}>📄 Dashboard</h1>

      {/* ===== STATS CARDS ===== */}
      <div style={statsGrid}>
        <StatCard title="Total" value={total} color="#6c63ff" />
        <StatCard title="Active" value={active} color="#2ecc71" />
        <StatCard title="Expiring Soon" value={expiringSoon} color="#f39c12" />
        <StatCard title="Expired" value={expired} color="#e74c3c" />
      </div>

      <Link to="/add-document">
        <button style={addBtn}>➕ Add Document</button>
      </Link>

      {/* ===== RECENT DOCUMENTS TABLE ===== */}
      <div style={card}>
        <table style={table}>
          <thead>
            <tr>
              <th style={th}>Title</th>
              <th style={th}>Issue Date</th>
              <th style={th}>Expiry Date</th>
            </tr>
          </thead>

          <tbody>
            {documents.length === 0 && (
              <tr>
                <td colSpan="3" style={{ textAlign: "center", padding: "12px" }}>
                  No documents added yet
                </td>
              </tr>
            )}

            {documents.map((doc) => (
              <tr key={doc.id}>
                <td style={td}>{doc.title}</td>
                <td style={td}>{formatDateTime(doc.issue_date)}</td>
                <td style={td}>{formatDateTime(doc.expiry_date)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ===== COMPONENT ===== */
function StatCard({ title, value, color }) {
  return (
    <div style={{ ...statCard, borderLeft: `6px solid ${color}` }}>
      <h4>{title}</h4>
      <h2>{value}</h2>
    </div>
  );
}

/* ===== STYLES ===== */

const page = {
  padding: "30px",
  background: "#f5f7fb",
  minHeight: "100vh",
};

const statsGrid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
  gap: "20px",
  marginBottom: "30px",
};

const statCard = {
  background: "#fff",
  padding: "20px",
  borderRadius: "12px",
  boxShadow: "0 10px 25px rgba(0,0,0,0.08)",
};

const addBtn = {
  padding: "10px 16px",
  background: "#6c63ff",
  color: "#fff",
  border: "none",
  borderRadius: "8px",
  cursor: "pointer",
  marginBottom: "20px",
};

const card = {
  background: "#fff",
  padding: "20px",
  borderRadius: "12px",
  boxShadow: "0 10px 25px rgba(0,0,0,0.08)",
};

const table = {
  width: "100%",
  borderCollapse: "collapse",
};

const th = {
  textAlign: "left",
  padding: "10px",
};

const td = {
  padding: "12px 10px",
};
