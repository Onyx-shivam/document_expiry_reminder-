import React, { useEffect, useState } from "react";
import api from "../services/api";

export default function Documents() {
  const [docs, setDocs] = useState([]);

  const loadDocs = async () => {
    try {
      const res = await api.get("/documents");
      setDocs(res.data);
    } catch {
      alert("Failed to load documents");
    }
  };

  useEffect(() => {
    loadDocs();
  }, []);

  const deleteDoc = async (id) => {
    if (!window.confirm("Delete this document?")) return;
    await api.delete(`/documents/${id}`);
    loadDocs();
  };

  const getStatus = (expiryDate) => {
    const today = new Date();
    const exp = new Date(expiryDate);
    const diffDays = Math.ceil((exp - today) / (1000 * 60 * 60 * 24));

    if (diffDays < 0) return { text: "EXPIRED", color: "#dc3545" };
    if (diffDays <= 7) return { text: "EXPIRING", color: "#ffc107" };
    return { text: "ACTIVE", color: "#28a745" };
  };

  return (
    <div className="layout">
      <div className="content">
        <h2>📄 My Documents</h2>

        {docs.length === 0 ? (
          <p>No documents added yet.</p>
        ) : (
          <div style={grid}>
            {docs.map((d) => {
              const status = getStatus(d.expiry_date);
              return (
                <div key={d.id} style={card}>
                  <div
                    style={{
                      ...badge,
                      background: status.color,
                    }}
                  >
                    {status.text}
                  </div>

                  <h5>{d.title}</h5>
                  <p><strong>Issue:</strong> {d.issue_date}</p>
                  <p><strong>Expiry:</strong> {d.expiry_date}</p>
                  <p><strong>Reminder:</strong> {d.reminder_days} days before</p>

                  <button
                    className="btn btn-sm btn-danger mt-2"
                    onClick={() => deleteDoc(d.id)}
                  >
                    Delete
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

/* ===== STYLES ===== */

const grid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))",
  gap: "20px",
  marginTop: "20px",
};

const card = {
  background: "#fff",
  padding: "20px",
  borderRadius: "12px",
  boxShadow: "0 6px 15px rgba(0,0,0,0.1)",
  position: "relative",
};

const badge = {
  position: "absolute",
  top: "12px",
  right: "12px",
  padding: "5px 10px",
  color: "#000",
  fontSize: "12px",
  borderRadius: "20px",
  fontWeight: "bold",
};
