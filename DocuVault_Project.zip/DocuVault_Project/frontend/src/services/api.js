import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:5000",
});

/* Attach JWT token */
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

/* ❌ DO NOT auto-logout on errors */
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // Just pass error to component
    return Promise.reject(error);
  }
);

export default api;
