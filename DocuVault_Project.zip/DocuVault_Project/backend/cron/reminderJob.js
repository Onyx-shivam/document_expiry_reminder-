const cron = require("node-cron");
const db = require("../db");
const sendEmail = require("../utils/sendEmail");

// ⏰ FOR TESTING: runs every minute
// cron.schedule("* * * * *", async () => {

// ⏰  runs every day at 9 
cron.schedule("0 9 * * *",async () => {


  console.log("🔔 Running document expiry reminder job...");

  try {
    const [docs] = await db.query(
      `SELECT 
        d.id,
        d.title,
        d.expiry_date,
        d.reminder_days,
        d.reminder_sent,
        u.email
       FROM documents d
       JOIN users u ON d.user_id = u.id
       WHERE d.reminder_sent = 0`
    );

    // normalize today's date (remove time)
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    for (const doc of docs) {
      // normalize expiry date (remove time)
      const expiryDate = new Date(doc.expiry_date);
      expiryDate.setHours(0, 0, 0, 0);

      const daysLeft = Math.round(
        (expiryDate - today) / (1000 * 60 * 60 * 24)
      );

      console.log(
        `📄 ${doc.title} → daysLeft=${daysLeft}, reminder=${doc.reminder_days}`
      );

      // send reminder on exact day
      if (daysLeft === Number(doc.reminder_days)) {
        const isExpired = daysLeft < 0;

        const subject = isExpired
          ? `❌ Expired: ${doc.title}`
          : `⏰ Reminder: ${doc.title} expires in ${daysLeft} day(s)`;

        const html = `
        <div style="font-family: Arial, sans-serif; background:#f5f7fb; padding:20px;">
          <div style="max-width:600px; margin:auto; background:#ffffff; padding:25px; border-radius:10px;">
            
            <h2 style="color:#6c63ff;">📄 DocuVault Reminder</h2>

            <p>Hello,</p>

            <p>
              This is an automated reminder regarding one of your saved documents
              in <strong>DocuVault</strong>.
            </p>

            <hr style="margin:20px 0;" />

            <table style="width:100%; border-collapse:collapse;">
              <tr>
                <td style="padding:8px;"><strong>Document Name</strong></td>
                <td style="padding:8px;">${doc.title}</td>
              </tr>
              <tr>
                <td style="padding:8px;"><strong>Expiry Date</strong></td>
                <td style="padding:8px;">${expiryDate.toDateString()}</td>
              </tr>
              <tr>
                <td style="padding:8px;"><strong>Status</strong></td>
                <td style="padding:8px; color:${isExpired ? "#e74c3c" : "#f39c12"};">
                  ${
                    isExpired
                      ? "Expired"
                      : `Expires in ${daysLeft} day(s)`
                  }
                </td>
              </tr>
            </table>

            <hr style="margin:20px 0;" />

            <p>
              ${
                isExpired
                  ? "⚠️ This document has already expired. Please renew or update it as soon as possible."
                  : "⏳ Please make sure to renew or update this document before it expires to avoid any inconvenience."
              }
            </p>

            <p style="margin-top:30px;">
              You can log in to DocuVault anytime to manage your documents.
            </p>

            <p style="margin-top:20px;">
              Regards,<br/>
              <strong>DocuVault Team</strong><br/>
              <span style="color:#777;">Document Expiry Reminder System</span>
            </p>

          </div>
        </div>
        `;

        await sendEmail(doc.email, subject, html);

        await db.query(
          "UPDATE documents SET reminder_sent = 1 WHERE id = ?",
          [doc.id]
        );

        console.log(`✅ Reminder email sent for: ${doc.title}`);
      }
    }
  } catch (err) {
    console.error("❌ Reminder job error:", err.message);
  }
});
