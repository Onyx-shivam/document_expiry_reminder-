const express = require("express");
const router = express.Router();
const db = require("../db");
const authMiddleware = require("../middleware/authMiddleware");

const multer = require("multer");
const path = require("path");

/* ===== MULTER CONFIG ===== */
const storage = multer.diskStorage({
  destination: "uploads/",
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({ storage });

/* ===== GET ALL DOCUMENTS ===== */
router.get("/", authMiddleware, async (req, res) => {
  try {
    const [rows] = await db.query(
      "SELECT * FROM documents WHERE user_id = ? ORDER BY expiry_date ASC",
      [req.user.id]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Server error" });
  }
});

/* ===== ADD DOCUMENT (WITH FILE) ===== */
router.post(
  "/",
  authMiddleware,
  upload.single("document"),
  async (req, res) => {
    const { title, issue_date, expiry_date, reminder_days } = req.body;
    const filePath = req.file ? req.file.path : null;

    try {
      await db.query(
        `INSERT INTO documents 
        (user_id, title, issue_date, expiry_date, reminder_days, file_path)
        VALUES (?, ?, ?, ?, ?, ?)`,
        [
          req.user.id,
          title,
          issue_date,
          expiry_date,
          reminder_days || 0,
          filePath,
        ]
      );

      res.json({ msg: "Document added successfully" });
    } catch (err) {
      console.error(err);
      res.status(500).json({ msg: "Server error" });
    }
  }
);

/* ===== DELETE DOCUMENT ===== */
router.delete("/:id", authMiddleware, async (req, res) => {
  const { id } = req.params;

  try {
    const [result] = await db.query(
      "DELETE FROM documents WHERE id = ? AND user_id = ?",
      [id, req.user.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ msg: "Document not found" });
    }

    res.json({ msg: "Document deleted successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Server error" });
  }
});


module.exports = router;
