const express = require("express");
const db = require("../db");
const auth = require("../middleware/authMiddleware");
const router = express.Router();

router.get("/me", auth, (req, res) => {
  db.query("SELECT id,name,email,created_at FROM users WHERE id=?",
    [req.user.id], (err, rows) => res.json(rows[0]));
});

module.exports = router;
