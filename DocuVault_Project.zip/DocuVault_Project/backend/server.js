require("dotenv").config();
require("./cron/reminderJob");


const express = require("express");
const cors = require("cors");




/* 🔔 START CRON JOB (IMPORTANT) */
// require("./cron/reminderJob");   // ✅ ONLY import cron here

const authRoutes = require("./routes/auth");
const documentRoutes = require("./routes/documents");

const app = express();

/* ===== GLOBAL MIDDLEWARE ===== */
app.use(cors());
app.use(express.json());
app.use("/uploads", express.static("uploads"));

/* ===== ROUTES ===== */
app.use("/auth", authRoutes);
app.use("/documents", documentRoutes);

/* ===== HEALTH CHECK ===== */
app.get("/", (req, res) => {
  res.send("Backend running successfully");
});

/* ===== START SERVER ===== */
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
